# NEXUS 1

![Screenshot (37)](https://user-images.githubusercontent.com/75037497/121324469-64197280-c92e-11eb-8633-8c86b6093d33.png)

---

<h4 align="left">NEXUS-1 is a VR cum AR application created with the help of Unity Engine, Vuforia Engine and Google AR Core.</h4>
<h4 align="left">The complete Documentation of the Application with full research done can be found in the Final and Complete Presentation provided.</h4>
<h4 align="left">The Link for the demo video - https://www.youtube.com/watch?v=lEhBADiDEQQ </h4>


⭐️ From [AnmolJindal2019](https://github.com/AnmolJindal2019)
